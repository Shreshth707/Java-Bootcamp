package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.example.demo.dao.EmployeeDao;
import com.example.demo.entity.Employee;

@Service
public class SampleService {
	@Autowired
	private EmployeeDao employeeDao;
	
	@Autowired
	private EmailService emailService;
	
	public void insert(Employee e) {
		employeeDao.addEmployee(e);
		emailService.sendEmail("Employee added !!!");
	}
}
