package com.example.demo.dao;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Employee;

@Profile("dev")
@Repository("jdbc")
public class EmployeeDaoJdbcImpl implements EmployeeDao {
	@Autowired
	private DataSource dataSource;
	
	@Override
	public void addEmployee(Employee e) {
		try {
			System.out.println(dataSource.getConnection());
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		System.out.println("Stored in MySQL!!!");
	}

}
