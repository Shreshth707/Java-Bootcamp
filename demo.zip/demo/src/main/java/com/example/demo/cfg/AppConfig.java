package com.example.demo.cfg;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.demo.service.EmailService;
import com.mchange.v2.c3p0.ComboPooledDataSource;

@Configuration
public class AppConfig {
	
	@Value("${emailserver}")
	private String ipaddress;
	
	@Value("${emailport}")
	private int port;
	
	// factory method
	@Bean
	public DataSource dataSource() throws Exception {
		ComboPooledDataSource cpds = new ComboPooledDataSource();
		cpds.setDriverClass("com.mysql.cj.jdbc.Driver"); // loads the jdbc driver
		cpds.setJdbcUrl("jdbc:mysql://localhost:3306/sample_db");
		cpds.setUser("root");
		cpds.setPassword("Welcome123");
		// the settings below are optional -- c3p0 can work with defaults
		cpds.setMinPoolSize(5);
		cpds.setAcquireIncrement(5);
		cpds.setMaxPoolSize(20);
		return cpds;
	}
	
	@Bean
	public EmailService emailService() {
		return new EmailService(ipaddress, port);
	}
}
