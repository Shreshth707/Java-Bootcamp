package com.example.demo.entity;

public class Employee {

}
