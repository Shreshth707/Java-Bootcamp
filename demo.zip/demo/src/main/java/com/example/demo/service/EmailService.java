package com.example.demo.service;

public class EmailService {
	String ip;
	int port;
	
	public EmailService(String ip, int port) {
		this.ip = ip;
		this.port = port;
	}
	
	void sendEmail(String msg) {
		System.out.println("Email Sent " + msg + " to " + ip + ":" + port);
	}
	
}
