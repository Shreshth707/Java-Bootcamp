package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Employee;
import com.example.demo.service.SampleService;

@Component
public class EmployeeClient implements CommandLineRunner {
	@Autowired
	private SampleService service;
	// this method gets called as soon as spring container is created
	@Override
	public void run(String... args) throws Exception {
		service.insert(new Employee());
	}

}
