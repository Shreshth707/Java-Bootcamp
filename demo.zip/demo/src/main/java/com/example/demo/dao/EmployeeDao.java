package com.example.demo.dao;

import com.example.demo.entity.Employee;

public interface EmployeeDao {
	void addEmployee(Employee e);
}
