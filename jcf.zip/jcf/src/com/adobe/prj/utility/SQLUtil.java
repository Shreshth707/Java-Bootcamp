package com.adobe.prj.utility;

import java.lang.reflect.Field;

import com.adobe.prj.annotation.Column;
import com.adobe.prj.annotation.Table;

public class SQLUtil {
	// OCP
	public static String getCreateStatement(Class<?> clazz) {
		StringBuffer buffer = new StringBuffer();
			Table t = clazz.getAnnotation(Table.class);
			if(t != null) {
				buffer.append("create table ");
				buffer.append(t.name());
				buffer.append("("); //create table products (
				Field[] fields = clazz.getDeclaredFields();
				for(Field f: fields) {
					Column col = f.getAnnotation(Column.class);
					if(col != null) {
						buffer.append(col.name());
						buffer.append(" ");
						buffer.append(col.type());
						buffer.append(","); // create table products ( pid NuMERIC(12), 
					}
				}
			}
		buffer.setCharAt(buffer.lastIndexOf(","), ')');
		return buffer.toString();
	}
}
