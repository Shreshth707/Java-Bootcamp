package com.adobe.prj.entity;

import com.adobe.prj.annotation.Column;
import com.adobe.prj.annotation.Table;

@Table(name="books")
public class Book {
	@Column(name="ISBN")
	private String isbn;
	@Column(name="BOOK_TITLE")
	private String title;
}
