package com.adobe.prj.client;

import com.adobe.prj.entity.Book;
import com.adobe.prj.entity.Product;
import com.adobe.prj.utility.SQLUtil;

public class Test {

	public static void main(String[] args) {
		 String SQL = SQLUtil.getCreateStatement(Product.class);
		 System.out.println(SQL);
		 
		 SQL = SQLUtil.getCreateStatement(Book.class);
		 System.out.println(SQL);
	}

}
