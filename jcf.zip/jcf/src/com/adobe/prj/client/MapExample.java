package com.adobe.prj.client;

import java.util.HashMap;
import java.util.Map;

public class MapExample {

	public static void main(String[] args) {
		//Map<String, Double> bookCost = new HashMap<>();
		
		Map<String, Double> bookCost = new HashMap<>(10, 0.75f);
		
		bookCost.put("JavaScript", 670.11);
		bookCost.put("Java", 1270.10);
		bookCost.put("Ruby", 8970.00);
		bookCost.put("Python", 400.00);
		
		bookCost.put("Java", 2555.00); // over write
		
		System.out.println(bookCost.get("Java"));
		
		// traverse thro entries
		bookCost.forEach((k,v) -> {
			System.out.println(k + " : " + v);
		});
	}

}
