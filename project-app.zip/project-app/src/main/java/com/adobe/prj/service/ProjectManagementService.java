package com.adobe.prj.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adobe.prj.dao.ProjectDao;
import com.adobe.prj.entity.Project;

@Service
public class ProjectManagementService {
	@Autowired
	private ProjectDao projectDao;
	
	public Project addProject(Project p) {
		return projectDao.save(p);
	}
}
