package com.adobe.prj.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adobe.prj.entity.Project;

public interface ProjectDao extends JpaRepository<Project, Integer> {

}
