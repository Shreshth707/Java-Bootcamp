package com.adobe.prj.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="projects")
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class Project {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="project_id")
	private int projectId;
	
	private String name;
	
	private String client;
	
	@JsonFormat(pattern = "dd-MM-yyyy", shape = Shape.STRING)
	@Temporal(TemporalType.DATE)
	@Column(name="start_date")
	private Date startDate;
	
	@JsonFormat(pattern = "dd-MM-yyyy", shape = Shape.STRING)
	@Temporal(TemporalType.DATE)
	@Column(name="end_date")
	private Date endDate;
	
}
