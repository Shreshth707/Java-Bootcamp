package com.adobe.prj.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.adobe.prj.entity.Project;
import com.adobe.prj.service.ProjectManagementService;

@RestController
@RequestMapping("api/projects")
public class ProjectController {
	@Autowired
	private ProjectManagementService service;
	
	@PostMapping()
	public @ResponseBody Project addProject(@RequestBody Project p) {
		return service.addProject(p);
	}
}
