package com.adobe.prj.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adobe.prj.dao.MovieDao;
import com.adobe.prj.entity.Movie;

@Service
public class MovieService {
	@Autowired
	private MovieDao movieDao;
	
	@Transactional
	public Movie addMovie(Movie movie) {
		return movieDao.save(movie);
	}
	
	public List<Movie> getMovies() {
		return movieDao.findAll();
	}
}
