package com.adobe.prj;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.adobe.prj.entity.Actor;
import com.adobe.prj.entity.Movie;
import com.adobe.prj.service.MovieService;

@Component
public class MovieClient implements CommandLineRunner {
	@Autowired
	MovieService service;
	
	@Override
	public void run(String... args) throws Exception {
		Movie movie = new Movie();
		movie.setName("Pulp Fiction");
		List<Actor> actors = new ArrayList<>();
		actors.add(Actor.builder().name("Bruce Wills").build());
		actors.add(Actor.builder().name("Uma Thruman").build());
		actors.add(Actor.builder().name("Travolta").build());
		
		movie.setActors(actors); 
		service.addMovie(movie);
	}

}
