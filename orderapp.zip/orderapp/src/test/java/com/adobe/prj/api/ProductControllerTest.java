package com.adobe.prj.api;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.adobe.prj.entity.Product;
import com.adobe.prj.service.OrderService;
import com.fasterxml.jackson.databind.ObjectMapper;

// static imports
import static org.mockito.Mockito.*;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.*;

import static org.hamcrest.Matchers.*;

@WebMvcTest(ProductController.class)
public class ProductControllerTest {
	@MockBean
	private OrderService service;
	
	@Autowired
	private MockMvc mockMvc;
	
	@Test
	public void getProductsTest() throws Exception {
		List<Product> products = Arrays.asList(new Product(1,"a", 1200.00, 100), 
				new Product(2,"b", 6200.00, 100));
		
		// mocking
		when(service.getProducts()).thenReturn(products);
		
		mockMvc.perform(get("/api/products"))
			.andExpect(status().isOk())
			.andExpect(jsonPath("$", hasSize(2)))
			.andExpect(jsonPath("$[0].name", is("a")))
			.andExpect(jsonPath("$[1].name", is("b")));
		
		verify(service, times(1)).getProducts();
	}
	
	@Test
	public void addProduct() throws Exception {
		Product p = new Product(0, "test", 1200.00, 100);
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(p); // get JSON from Product p
		
		when(service.addProduct(Mockito.any(Product.class))).thenReturn(Mockito.any(Product.class));
		
		mockMvc.perform(post("/api/products")
		.content(json)
		.contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isCreated());
		
		verify(service, times(1)).addProduct(Mockito.any(Product.class));
	}
	
	@Test
	public void addProductException() throws Exception {
		Product p = new Product(0, "", -1200.00, 100);
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(p); // get JSON from Product p
		
//		when(service.addProduct(Mockito.any(Product.class))).thenReturn(Mockito.any(Product.class));
		
		mockMvc.perform(post("/api/products")
		.content(json)
		.contentType(MediaType.APPLICATION_JSON))
		.andExpect(jsonPath("$.errors", hasSize(2)))
		.andExpect(jsonPath("$.errors", hasItem("Name is required")))
		.andExpect(jsonPath("$.errors", hasItem("Price -1200.0 should be greater than 10")))
		.andExpect(status().isBadRequest());
		
		verifyNoInteractions(service);
	}
}

