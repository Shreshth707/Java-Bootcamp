package com.adobe.prj;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import com.adobe.prj.entity.Product;
import com.adobe.prj.service.OrderService;
import com.adobe.prj.service.ResourceNotFoundException;

//@Component
public class ProductClient implements CommandLineRunner {
	@Autowired
	private OrderService service;

	@Override
	public void run(String... args) throws Exception {
//		insertProduct();
//		printProducts();
//		updateProductJPQL();
//		getByRange();
//		paginate();
	}

	private void paginate() {
		Page<Product> productPage = service.paginage(1, 2);
		System.out.println("Total Pages: " + productPage.getTotalPages());
		System.out.println("# " + productPage.getNumber());
		List<Product> products = productPage.getContent();
		for(Product p : products) {
			System.out.println(p);
		}
	}

	private void getByRange() {
		List<Product> products = service.getByRange(500, 1000);
		for(Product p : products) {
			System.out.println(p);
		}
	}

	private void updateProductJPQL() throws ResourceNotFoundException {
		Product p = service.updateProduct(4, 3);
		System.out.println(p);
	}

	private void printProducts() {
		List<Product> products = service.getProducts();
		for(Product p : products) {
			System.out.println(p);
		}
	}

	private void insertProduct() {
		Product p = new Product(0, "Koflet", 2.50, 1000);
		service.addProduct(p);
	}
	
}
