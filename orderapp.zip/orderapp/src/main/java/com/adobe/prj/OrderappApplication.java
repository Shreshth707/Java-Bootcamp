package com.adobe.prj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;

@SpringBootApplication
public class OrderappApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderappApplication.class, args);
	}

	@Bean
    public OpenAPI openApi() {
        return new OpenAPI()
                .info(new Info()
                        .title("Adobe Order application")
                        .description("RESTful  API")
                        .version("v1.0")
                        .contact(new Contact()
                                .name("mySelf")
                                .url("https://adobe.com")
                                .email("me@gmail.com"))
                        .termsOfService("TOC")
                        .license(new License().name("License").url("#"))
                );
    }
}
