package com.adobe.prj;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.adobe.prj.entity.Customer;
import com.adobe.prj.entity.Item;
import com.adobe.prj.entity.Order;
import com.adobe.prj.entity.Product;
import com.adobe.prj.entity.ReportDTO;
import com.adobe.prj.service.OrderService;

//@Component
public class OrderClient implements CommandLineRunner {
	@Autowired
	private OrderService service;

	@Override
	public void run(String... args) throws Exception {
//		addOrder();
//		getOrders();
		getReport();
	}

	private void getReport() {
		List<ReportDTO> reportDTOs = service.getReport();
		for(ReportDTO reportDTO : reportDTOs) {
			System.out.println(reportDTO);
		}
	}

	private void getOrders() {
		List<Order> orders = service.getOrders();
		for(Order o : orders) {
			System.out.println(o.getOid() + " |  " + o.getCustomer().getEmail() + "," + o.getCustomer().getFirstName() + " | " + o.getTotal() + " | " + o.getOrderDate());
			System.out.println("Items");
			List<Item> items = o.getItems();  
			for(Item item : items) {
				System.out.println(item.getProduct().getName()  + " | " + item.getQty() + " | " + item.getAmount());
			}
		}
	}

	private void addOrder() {
		List<Item> items = new ArrayList<>();
		Product p1 = Product.builder().id(2).build();
		Product p2 = Product.builder().id(1).build();
		Item i1 = Item.builder()
					.product(p1)
					.qty(3)
					.build();
		
		Item i2 = Item.builder()
					.product(p2)
					.qty(1)
					.build();
		
		items.add(i1);
		items.add(i2);
		
		Order order  = new Order();
		order.setItems(items);
		Customer c = Customer.builder()
					.email("b@adobe.com")
					.build();
		order.setCustomer(c);
		
		service.placeOrder(order);
	}

}
