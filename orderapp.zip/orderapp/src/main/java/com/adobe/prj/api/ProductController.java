package com.adobe.prj.api;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.adobe.prj.entity.Product;
import com.adobe.prj.service.OrderService;
import com.adobe.prj.service.ResourceNotFoundException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("api/products")
@Validated
@Tag(name="products", description = "Product Restful API")
@CrossOrigin()
public class ProductController {
	@Autowired
	private OrderService service;
	
	//http://localhost:8080/api/products
	//http://localhost:8080/api/products?low=100&high=1000
	@GetMapping()
	public @ResponseBody List<Product> getProducts(@RequestParam(name="low", defaultValue = "0.0") double l,
			@RequestParam(name="high", defaultValue = "0.0") double h) {
		if(l == 0.0 & h == 0.0) {
			return service.getProducts();
		} else {
			return service.getByRange(l, h);
		}
	}
	
	// http://localhost:8080/api/products/4
	@Operation(summary = "Get a product by its id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description =  "Found the product for ID",
					content = {@Content(mediaType = "application/json")}),
			@ApiResponse(responseCode = "404", description = "Product not found!!")
			})
	@GetMapping("/{id}")
	public @ResponseBody Product getProduct(@PathVariable("id") int id) throws ResourceNotFoundException {
		return service.getProductById(id);
	}
	
	/* 
	 * POST
	 * http://localhost:8080/api/products
	 * 
	 * Body:
	 * {
	 *   name: "a",
	 *   price: 2344.33
	 * }
	 * 
	 */
	@PostMapping()
	public  ResponseEntity<Product>  addProduct(@RequestBody @Valid Product p) {
		 service.addProduct(p);
		return new ResponseEntity<Product>(p, HttpStatus.CREATED);
	}
	
	/* 
	 * PUT
	 * http://localhost:8080/api/products/4
	 * 
	 * Body:
	 * {
	 *   price: 2344.33
	 * }
	 * 
	 */
	
	@PutMapping("/{id}")
	public @ResponseBody Product update(@PathVariable("id") int id, @RequestBody Product p) throws ResourceNotFoundException {
		return service.updateProduct(id, p.getPrice());
	}
}
