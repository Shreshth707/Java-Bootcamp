package com.adobe.prj.ui;

import com.adobe.prj.entity.Product;
import com.adobe.prj.entity.Tv;

public class Test {

	public static void main(String[] args) {
		Product p1 = new Tv(133, "Sony Bravia", 135000.00, "LED");  
		Product p2 = new Tv(133, "Sony Bravia", 135000.00, "LED");  
		Product p = p1;  
		
		System.out.println(p); // object passed as argument to println
		// com.adobe.prj.entity.Tv@6d06d69c ==> toString()
		
		if(p == p1) {
			System.out.println("p1 and p are same");
		}
		
		if(p1.equals(p2)) {
			System.out.println("p1 and p2 have same data!!!!");
		}
	}

}
