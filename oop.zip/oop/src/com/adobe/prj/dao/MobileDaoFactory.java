package com.adobe.prj.dao;

import java.util.ResourceBundle;

public class MobileDaoFactory {
	private static String DAO = ""; // from config.properties

	static {
		ResourceBundle res = ResourceBundle.getBundle("config");
		DAO = res.getString("MOBILE_DAO");
	}

	public static MobileDao getMobileDao() {
		try {
			return (MobileDao) Class.forName(DAO).newInstance();
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
//		return new MobileDaoMySqlImpl();
	}
}
