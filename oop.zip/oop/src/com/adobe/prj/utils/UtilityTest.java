package com.adobe.prj.utils;

import static org.junit.Assert.*;

import org.junit.Test;

public class UtilityTest {

//	@Test
	public void testSort() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindSum() {
		int[] data = {5,4,1};
		int expected = 10;
		assertEquals(expected, Utility.findSum(data));
	}

}
